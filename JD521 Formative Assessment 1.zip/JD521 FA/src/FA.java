import javax.swing.*; // This package is for the use of Joptionpane

public class FA {
    private double balance;
    private JFrame f;

    public FA() {
        balance = 100000; //This is the starting balance in the bank account
        f = new JFrame(); //This is a new JFrame object to display JOptionPane
    }

    public void deposit() { //This method is for Depositing money in the exisiting Bank Account
        try { // Try Exception is to catch errors if the user adds the incorrect input
            int depositAmount = Integer.parseInt(JOptionPane.showInputDialog(null, "How much money you do you want to deposit?"));
            if (depositAmount <= 0) {
                JOptionPane.showMessageDialog(f, "Invalid deposit amount.");
                return;
            }
            balance += depositAmount;//Add the deposit amount to the balance
            JOptionPane.showMessageDialog(f, "The new balance you have is \n \n R " + balance);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(f, "Invalid input.");
        }
    }

    public void withdraw() { // This method is for withdrawing money in the existing Bank Account.
        try {// Try Exception is to catch errors if the user adds the incorrect input
            int withdrawAmount = Integer.parseInt(JOptionPane.showInputDialog(null, "How much money you do you want to withdraw?"));
            if (withdrawAmount <= 0) {
                JOptionPane.showMessageDialog(f, "Invalid withdraw amount.");
                return;
            }
            if (balance < withdrawAmount) {
                JOptionPane.showMessageDialog(f, "Insufficient funds.");
                return;
            }
            balance -= withdrawAmount;//Subtract the withdraw amount from the balance
            JOptionPane.showMessageDialog(f, "The new balance you have is \n \n R " + balance);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(f, "Invalid input.");
        }
    }

    public void save() {// This method is for Saving or investing money and added in the bank account.
        try {// Try Exception is to catch errors if the user adds the incorrect input
            int saveAmount = Integer.parseInt(JOptionPane.showInputDialog(null, "How much money you do you want to save?"));
            if (saveAmount <= 0) {
                JOptionPane.showMessageDialog(f, "Invalid save amount.");
                return;
            }
            double interest = 0;
            if (saveAmount < 500) {
                interest = saveAmount * 1 / 200.0;
            } else if (saveAmount < 1000) {
                interest = saveAmount * 2 / 100.0;
            } else {
                interest = saveAmount * 5 / 100.0;
            }
            balance += saveAmount + interest;
            JOptionPane.showMessageDialog(f, "The new balance you have is \n \n R " + balance);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(f, "Invalid input.");
        }
    }

    public void checkBalance() {
        JOptionPane.showMessageDialog(f, "Your current balance is \n \n R " + balance);
    }

    public void exit() {// This method is for exiting the program.
        JOptionPane.showMessageDialog(f, "Good Bye.");
        System.exit(0);
    }

    public void run() {
        while (true) {
            try {// Try Exception is to catch errors if the user adds the incorrect input
                int option = Integer.parseInt(JOptionPane.showInputDialog(null,
                        "Press 1 to Deposit \nPress 2 to Withdraw \nPress 3 to Save \nPress 4 to Check Balance \nPress 5 to Exit"));
                switch (option) { //The use of Switch case is to call the method if the user chooses the optiom
                    case 1:
                        deposit();
                        break;
                    case 2:
                        withdraw();
                        break;
                    case 3:
                        save();
                        break;
                    case 4:
                        checkBalance();
                        break;
                    case 5:
                        exit();
                        break;
                    default: 
                        JOptionPane.showMessageDialog(f, "Invalid option.");
                        break;
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(f, "Invalid input.");
            }
        }
    }

    public static void main(String[] args) {
        FA account = new FA();
        account.run();
    }
}
